SELECT 
    customer_id,
    SUM(revenue) AS customer_lifetime_value
FROM online_retail
GROUP BY customer_id
ORDER BY customer_lifetime_value DESC;
