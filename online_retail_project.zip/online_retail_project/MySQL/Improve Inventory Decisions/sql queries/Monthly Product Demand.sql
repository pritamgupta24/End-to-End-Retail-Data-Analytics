SELECT 
    DATE_FORMAT(invoice_date, '%Y-%m') AS month,
    description,
    SUM(quantity) AS monthly_units_sold
FROM online_retail
GROUP BY month, description
ORDER BY month, monthly_units_sold DESC;
