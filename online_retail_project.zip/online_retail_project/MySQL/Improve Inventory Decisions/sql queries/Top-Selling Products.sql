SELECT 
    description,
    SUM(quantity) AS total_units_sold
FROM online_retail
GROUP BY description
ORDER BY total_units_sold DESC
LIMIT 10;
