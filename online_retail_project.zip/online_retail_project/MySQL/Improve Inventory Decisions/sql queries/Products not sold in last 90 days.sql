SELECT 
    description,
    MAX(invoice_date) AS last_sold_date
FROM online_retail
GROUP BY description
HAVING DATEDIFF(CURDATE(), MAX(invoice_date)) > 90;
