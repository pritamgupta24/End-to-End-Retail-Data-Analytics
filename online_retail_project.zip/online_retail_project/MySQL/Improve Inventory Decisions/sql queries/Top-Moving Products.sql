SELECT 
    description,
    SUM(quantity) AS total_units_sold
FROM online_retail
GROUP BY description
HAVING total_units_sold < 50
ORDER BY total_units_sold ASC;
