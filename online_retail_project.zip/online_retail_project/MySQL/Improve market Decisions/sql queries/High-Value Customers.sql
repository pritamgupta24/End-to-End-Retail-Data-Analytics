SELECT 
    customer_id,
    COUNT(DISTINCT invoice_no) AS orders,
    SUM(revenue) AS total_spent
FROM online_retail
GROUP BY customer_id
ORDER BY total_spent DESC
LIMIT 10;
