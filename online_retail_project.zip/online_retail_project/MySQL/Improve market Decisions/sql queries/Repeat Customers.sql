SELECT 
    customer_id,
    COUNT(DISTINCT invoice_no) AS total_orders
FROM online_retail
GROUP BY customer_id
HAVING total_orders > 1;
