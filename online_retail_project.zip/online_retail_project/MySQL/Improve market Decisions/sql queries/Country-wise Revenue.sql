SELECT 
    country,
    SUM(revenue) AS total_revenue
FROM online_retail
GROUP BY country
ORDER BY total_revenue DESC;
