SELECT 
    country,
    SUM(revenue) / COUNT(DISTINCT invoice_no) AS avg_order_value
FROM online_retail
GROUP BY country
ORDER BY avg_order_value DESC;
