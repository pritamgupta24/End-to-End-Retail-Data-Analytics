SELECT 
    customer_id,
    MAX(invoice_date) AS last_purchase_date,
    DATEDIFF(CURDATE(), MAX(invoice_date)) AS days_inactive
FROM online_retail
GROUP BY customer_id
HAVING days_inactive BETWEEN 60 AND 90;
