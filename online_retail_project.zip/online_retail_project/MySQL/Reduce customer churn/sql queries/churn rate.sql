SELECT 
    (COUNT(DISTINCT churned.customer_id) * 100.0) /
    COUNT(DISTINCT all_customers.customer_id) AS churn_rate_percentage
FROM 
    (SELECT DISTINCT customer_id FROM online_retail) all_customers
LEFT JOIN
    (
        SELECT customer_id
        FROM online_retail
        GROUP BY customer_id
        HAVING DATEDIFF(CURDATE(), MAX(invoice_date)) > 90
    ) churned
ON all_customers.customer_id = churned.customer_id;
