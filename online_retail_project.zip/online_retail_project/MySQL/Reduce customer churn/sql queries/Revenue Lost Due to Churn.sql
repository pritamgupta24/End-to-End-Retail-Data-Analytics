SELECT 
    SUM(revenue) AS churned_revenue_loss
FROM online_retail
WHERE customer_id IN (
    SELECT customer_id
    FROM online_retail
    GROUP BY customer_id
    HAVING DATEDIFF(CURDATE(), MAX(invoice_date)) > 90
);
