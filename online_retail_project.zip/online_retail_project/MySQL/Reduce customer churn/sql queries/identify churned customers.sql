SELECT 
    customer_id,
    MAX(invoice_date) AS last_purchase_date,
    DATEDIFF(CURDATE(), MAX(invoice_date)) AS days_inactive
FROM online_retail
GROUP BY customer_id
HAVING days_inactive > 90
ORDER BY days_inactive DESC;
