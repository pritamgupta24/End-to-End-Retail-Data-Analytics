SELECT 
    SUM(revenue) / COUNT(DISTINCT invoice_no) AS avg_order_value
FROM online_retail;
