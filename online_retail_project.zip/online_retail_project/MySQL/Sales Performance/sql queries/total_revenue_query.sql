SELECT SUM(revenue) AS total_revenue
FROM online_retail;
