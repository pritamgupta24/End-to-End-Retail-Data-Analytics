SELECT 
    DATE_FORMAT(invoice_date, '%Y-%m') AS month,
    SUM(revenue) AS monthly_revenue
FROM online_retail
GROUP BY month
ORDER BY month;
